import express from "express";
const app = express();
app.use(express.json({ limit: "32kb" }));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/api/tone", async (req, res) => {
  const { request, guitar = "Stratocaster", ampModel = "NUX Mighty 20 BT MKII" } = req.body ?? {};
  if (typeof request !== "string" || request.trim().length < 3) {
    return res.status(400).json({ error: "Provide a song/tone request." });
  }
  // TODO: integrate the selected online AI provider here.
  // Require JSON output; validate it against a versioned amp/effect catalogue.
  // Never place provider API keys in the Android client.
  return res.status(501).json({
    error: "AI provider not configured",
    message: "Endpoint contract is ready; provider integration and amp catalogue are still required.",
    request: { request, guitar, ampModel },
    expectedSchema: {
      song: "string",
      artist: "string",
      guitarPart: "string",
      ampModel: "verified model name",
      parameters: { gain: 0, bass: 0, middle: 0, treble: 0, level: 0 },
      effects: [
        { block: "EFX", type: "verified type", enabled: true, parameters: {} },
        { block: "MOD", type: "verified type", enabled: false, parameters: {} },
        { block: "DLY", type: "verified type", enabled: true, parameters: {} },
        { block: "RVB", type: "verified type", enabled: true, parameters: {} }
      ],
      notes: "short rationale",
      confidence: "estimate"
    }
  });
});

app.listen(Number(process.env.PORT || 3000), () => console.log("Tone API running"));
