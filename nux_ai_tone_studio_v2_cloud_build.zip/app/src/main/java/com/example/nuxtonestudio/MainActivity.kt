package com.example.nuxtonestudio

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.widget.Toast

/**
 * Buildable Android discovery scaffold.
 *
 * This discovers nearby BLE devices and attempts to open a Bluetooth MIDI
 * device when selected. It deliberately DOES NOT send MIDI writes yet:
 * the exact Mighty 20 MKII SysEx/parameter map must be validated first.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var devicesBox: LinearLayout
    private lateinit var requestBox: EditText
    private lateinit var presetOutput: TextView
    private var midiDevice: MidiDevice? = null
    private var scannerCallback: ScanCallback? = null
    private val found = linkedMapOf<String, BluetoothDevice>()
    private val requestCode = 601

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBluetoothPermissionsIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(10, 15, 27))
        }
        root.addView(TextView(this).apply {
            text = "NUX AI TONE STUDIO"
            textSize = 24f
            setTextColor(Color.rgb(75, 190, 255))
        })
        root.addView(TextView(this).apply {
            text = "Mighty 20 BT MKII • AI preset builder"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 6, 0, 20)
        })
        status = TextView(this).apply {
            text = "Connection: not checked"
            textSize = 14f
            setTextColor(Color.rgb(255, 205, 90))
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Scan for amp / Bluetooth MIDI"
            setOnClickListener { startScan() }
        })
        root.addView(TextView(this).apply {
            text = "Nearby devices (tap a device to attempt MIDI connection)"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 12, 0, 6)
        })
        devicesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(devicesBox)

        root.addView(TextView(this).apply {
            text = "Describe the tone you want"
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(0, 22, 0, 6)
        })
        requestBox = EditText(this).apply {
            hint = "e.g. Floods — outro solo — Stratocaster"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(24, 33, 50))
            minLines = 3
            gravity = Gravity.TOP
            setPadding(14, 14, 14, 14)
        }
        root.addView(requestBox, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(Button(this).apply {
            text = "Generate complete preset (AI backend pending)"
            setOnClickListener {
                val text = requestBox.text.toString().trim()
                presetOutput.text = if (text.isBlank()) {
                    "Enter a song, artist, guitar part and guitar."
                } else {
                    "Request saved for the AI preset service:\\n$text\\n\\n" +
                    "The online AI endpoint is not configured in this build. Once connected, " +
                    "it will return a complete structured preset. Applying settings remains " +
                    "disabled until the amp's exact MIDI parameter map is verified."
                }
            }
        })
        presetOutput = TextView(this).apply {
            text = "Generated preset will appear here."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 18)
        }
        root.addView(presetOutput)
        root.addView(TextView(this).apply {
            text = "Safety: this version scans and attempts a MIDI connection only. It does not " +
                "write unknown commands to your amplifier."
            textSize = 12f
            setTextColor(Color.LTGRAY)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestBluetoothPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val needed = arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), requestCode)
        }
    }

    private fun startScan() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
             checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)) {
            requestBluetoothPermissionsIfNeeded()
            Toast.makeText(this, "Allow Bluetooth permissions, then scan again.", Toast.LENGTH_LONG).show()
            return
        }
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter = manager.adapter ?: run {
            status.text = "This phone has no Bluetooth adapter."
            return
        }
        if (!adapter.isEnabled) {
            status.text = "Turn Bluetooth on, then scan again."
            return
        }
        found.clear()
        devicesBox.removeAllViews()
        val scanner = adapter.bluetoothLeScanner ?: run {
            status.text = "BLE scanner unavailable."
            return
        }
        status.text = "Scanning for 10 seconds…"
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device
                val key = device.address ?: return
                if (!found.containsKey(key)) {
                    found[key] = device
                    runOnUiThread { addDeviceButton(device) }
                }
            }
            override fun onScanFailed(errorCode: Int) {
                runOnUiThread { status.text = "Bluetooth scan failed: $errorCode" }
            }
        }
        scannerCallback = callback
        try {
            scanner.startScan(callback)
            status.postDelayed({
                try { scanner.stopScan(callback) } catch (_: Exception) {}
                if (status.text.toString().startsWith("Scanning")) {
                    status.text = "Scan finished. Choose the NUX device if listed."
                }
            }, 10_000)
        } catch (e: SecurityException) {
            status.text = "Bluetooth permission denied."
        }
    }

    private fun addDeviceButton(device: BluetoothDevice) {
        val name = try { device.name ?: "Unnamed Bluetooth device" }
                   catch (_: SecurityException) { "Bluetooth device" }
        devicesBox.addView(Button(this).apply {
            text = "$name\n${device.address}"
            setOnClickListener { openMidi(device, name) }
        })
    }

    private fun openMidi(device: BluetoothDevice, name: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            return
        }
        val midiManager = getSystemService(Context.MIDI_SERVICE) as MidiManager
        status.text = "Attempting MIDI connection to $name…"
        try {
            midiManager.openBluetoothDevice(device, { opened ->
                runOnUiThread {
                    midiDevice?.close()
                    midiDevice = opened
                    status.text = if (opened != null) {
                        "MIDI device opened: $name. No amp commands sent."
                    } else {
                        "Could not open MIDI for $name. It may be Bluetooth audio only."
                    }
                }
            }, null)
        } catch (e: Exception) {
            status.text = "MIDI connection failed: ${e.message ?: "unknown error"}"
        }
    }

    override fun onDestroy() {
        try { scannerCallback?.let {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            manager.adapter?.bluetoothLeScanner?.stopScan(it)
        } } catch (_: Exception) {}
        try { midiDevice?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
