package com.example.nuxtonestudio

data class TonePreset(
    val song: String,
    val artist: String,
    val guitarPart: String,
    val ampModel: String?,
    val parameters: Map<String, Double>,
    val effects: List<EffectSetting>,
    val notes: String
)

data class EffectSetting(
    val block: String,
    val type: String,
    val enabled: Boolean,
    val parameters: Map<String, Double>
)
