# NUX AI Tone Studio v0.2 — Android starter

## Current state
- Android project structure and Gradle files included.
- Basic native UI included.
- BLE device scan and an attempt to open selected Bluetooth MIDI devices included.
- No MIDI messages are sent to the amp.
- Online AI endpoint contract included, but provider integration is not configured.
- Not yet verified on a physical NUX Mighty 20 BT MKII.

## Open in Android Studio
1. Extract this ZIP.
2. Open the `nux_ai_tone_studio_v2` folder in Android Studio.
3. Let Gradle sync; install Android SDK 35 if prompted.
4. Run on an Android phone with Bluetooth enabled.
5. Grant Bluetooth permissions and tap “Scan for amp / Bluetooth MIDI”.
6. The NUX NBT-1 module may appear under a device name such as NUX NGA-20. Bluetooth audio and Bluetooth MIDI are separate; pair/connect them as described by NUX.
7. Select the MIDI-capable NUX device if it appears. This build only attempts to open the MIDI device and does not send commands.

## Why it does not apply presets yet
The exact SysEx/parameter IDs, valid values and effect-type enumerations must be confirmed from a trusted device-specific implementation or captured/tested against the actual amp. Sending guessed messages can cause unpredictable settings. The Mightier Amp open-source project lists Mighty 20 BT/40 BT as untested, so compatibility should not be assumed.

## AI backend
`backend/server.js` exposes:
- `GET /health`
- `POST /api/tone`

The endpoint currently returns HTTP 501 until an online AI provider is configured. Add a provider SDK and store the key as a server environment variable. Validate AI output against a verified amp capability catalogue before displaying an enabled “Apply to amp” action.

## Next development milestone
Integrate the verified Mighty 20 MKII parameter map, implement safe preset read/write, and test one parameter and preset recall on the physical amplifier. Then configure the AI provider and connect the mobile app to the backend.

## Build an APK online using GitHub Actions (phone-only)
1. In your phone browser, sign in to GitHub and create a **new private repository** named `nux-ai-tone-studio`.
2. Upload the project files from this ZIP into the repository, preserving folders. Make sure `.github/workflows/android-apk.yml` is included. GitHub's website may hide dot-folders in some upload flows; if so, use GitHub's web editor to create `.github/workflows/android-apk.yml` and paste in the workflow file from this ZIP.
3. Commit the files to the `main` branch. Open the repository's **Actions** tab and choose **Build Android APK**. If it has not run automatically, tap **Run workflow**.
4. When the run finishes successfully, open that run and download the artifact named `nux-ai-tone-studio-debug-apk`. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
5. Open the APK on your Android phone and allow installation from that source if Android asks. Only install APKs you built from the source you intended.

This creates a **debug/test APK**, not a Play Store release. The APK build only packages the current scaffold; it does not add verified amp commands or working AI preset generation. Those require further development and testing with the physical amp.
